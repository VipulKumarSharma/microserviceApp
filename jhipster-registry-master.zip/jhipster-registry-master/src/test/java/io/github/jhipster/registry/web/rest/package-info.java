package io.github.jhipster.registry.web.rest;
