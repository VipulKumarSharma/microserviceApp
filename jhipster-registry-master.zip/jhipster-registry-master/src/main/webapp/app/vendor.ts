/* after changing this file run 'yarn run webpack:build:vendor' or 'yarn install' or 'yarn run webpack:build' */
/* tslint:disable */
import '../content/scss/vendor.scss';
