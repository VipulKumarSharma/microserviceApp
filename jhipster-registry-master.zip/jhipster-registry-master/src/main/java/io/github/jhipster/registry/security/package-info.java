/**
 * Spring Security configuration.
 */
package io.github.jhipster.registry.security;
