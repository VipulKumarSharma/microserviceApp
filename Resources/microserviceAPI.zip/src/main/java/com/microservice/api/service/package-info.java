/**
 * Service layer beans.
 */
package com.microservice.api.service;
