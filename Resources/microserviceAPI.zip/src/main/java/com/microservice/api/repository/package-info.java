/**
 * Spring Data JPA repositories.
 */
package com.microservice.api.repository;
