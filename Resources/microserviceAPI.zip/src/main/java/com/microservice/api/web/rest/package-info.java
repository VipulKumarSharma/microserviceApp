/**
 * Spring MVC REST controllers.
 */
package com.microservice.api.web.rest;
