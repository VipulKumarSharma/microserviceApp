/**
 * JPA domain objects.
 */
package com.microservice.api.domain;
