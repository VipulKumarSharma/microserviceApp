/**
 * View Models used by Spring MVC REST controllers.
 */
package com.microservice.api.web.rest.vm;
