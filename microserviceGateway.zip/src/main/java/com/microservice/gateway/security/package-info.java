/**
 * Spring Security configuration.
 */
package com.microservice.gateway.security;
