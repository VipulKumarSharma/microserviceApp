/**
 * Spring MVC REST controllers.
 */
package com.microservice.gateway.web.rest;
