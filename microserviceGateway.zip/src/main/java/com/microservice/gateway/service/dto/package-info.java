/**
 * Data Transfer Objects.
 */
package com.microservice.gateway.service.dto;
