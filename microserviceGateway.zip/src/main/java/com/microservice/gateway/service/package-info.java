/**
 * Service layer beans.
 */
package com.microservice.gateway.service;
