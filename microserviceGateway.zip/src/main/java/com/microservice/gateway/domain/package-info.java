/**
 * JPA domain objects.
 */
package com.microservice.gateway.domain;
