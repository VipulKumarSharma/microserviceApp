/**
 * Spring Data JPA repositories.
 */
package com.microservice.gateway.repository;
